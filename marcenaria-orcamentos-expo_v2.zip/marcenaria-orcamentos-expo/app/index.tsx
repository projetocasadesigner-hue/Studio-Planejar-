import { useEffect, useState } from 'react';
import { Link, useFocusEffect } from 'expo-router';
import { View, FlatList, RefreshControl } from 'react-native';
import { Button, List, FAB, TextInput } from 'react-native-paper';
import { supabase } from '@/services/supabase';
import type { Project } from '@/types';

export default function Home() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');

  async function load() {
    setRefreshing(true);
    const { data, error } = await supabase.from('projects')
      .select('id, client_name, title, created_at')
      .order('created_at', { ascending: false });
    if (!error) setProjects(data as any);
    setRefreshing(false);
  }

  useFocusEffect(() => { load(); return () => {}; });

  return (
    <View style={{ flex:1 }}>
      <View style={{ padding: 12 }}>
        <TextInput mode="outlined" label="Buscar" value={search} onChangeText={setSearch} />
      </View>
      <FlatList
        data={projects.filter(p =>
          (p.client_name||'').toLowerCase().includes(search.toLowerCase()) ||
          (p.title||'').toLowerCase().includes(search.toLowerCase())
        )}
        keyExtractor={(item)=>item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} />}
        renderItem={({item}) => (
          <Link href={{ pathname: '/project/[id]', params: { id: item.id }}} asChild>
            <List.Item
              title={item.title || 'Projeto'}
              description={item.client_name || '—'}
              right={props => <List.Icon {...props} icon="chevron-right" />}
            />
          </Link>
        )}
        ItemSeparatorComponent={()=><View style={{height:1, backgroundColor:'#eee'}}/>}
      />
      <Link href="/project/new" asChild>
        <FAB icon="plus" style={{ position:'absolute', right:16, bottom:16 }} />
      </Link>
    </View>
  );
}
