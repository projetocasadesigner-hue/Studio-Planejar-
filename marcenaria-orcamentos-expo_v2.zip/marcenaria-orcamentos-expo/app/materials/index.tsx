import { useEffect, useState } from 'react';
import { View, FlatList } from 'react-native';
import { Button, List, TextInput } from 'react-native-paper';
import { Link } from 'expo-router';
import { supabase } from '@/services/supabase';

export default function Materials() {
  const [items, setItems] = useState<any[]>([]);
  const [q, setQ] = useState('');
  async function load() {
    const { data } = await supabase.from('materials').select('*').order('brand');
    setItems(data||[]);
  }
  useEffect(()=>{ load(); },[]);
  return (
    <View style={{ flex:1 }}>
      <View style={{ padding:12, flexDirection:'row', gap:8 }}>
        <TextInput style={{ flex:1 }} mode="outlined" label="Buscar" value={q} onChangeText={setQ} />
        <Link href="/materials/import" asChild><Button>Importar CSV</Button></Link>
      </View>
      <FlatList
        data={items.filter(x => (x.name||'').toLowerCase().includes(q.toLowerCase()))}
        keyExtractor={(it)=>it.id}
        renderItem={({item})=>(
          <List.Item
            title={`${item.category} · ${item.name}`}
            description={`${item.brand||''} • ${item.sku||''}`}
            right={props => <List.Icon {...props} icon="chevron-right" />}
          />
        )}
        ItemSeparatorComponent={()=><View style={{height:1, backgroundColor:'#eee'}}/>}
      />
    </View>
  );
}
