import { useState } from 'react';
import { View } from 'react-native';
import { Button, Text } from 'react-native-paper';
import * as DocumentPicker from 'expo-document-picker';
import Papa from 'papaparse';
import { supabase } from '@/services/supabase';

export default function ImportMaterials() {
  const [msg, setMsg] = useState<string|null>(null);

  async function pickFile() {
    setMsg(null);
    const res = await DocumentPicker.getDocumentAsync({ type: 'text/*', copyToCacheDirectory: true });
    if (res.canceled || !res.assets?.length) return;
    const file = res.assets[0];
    const text = await fetch(file.uri).then(r=>r.text());
    const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
    const rows = (parsed.data as any[]).map(r => ({
      category: r.category, brand: r.brand, sku: r.sku, name: r.name, base_unit: r.base_unit,
      attributes: r.attributes ? JSON.parse(r.attributes) : {}
    }));
    const { error } = await supabase.from('materials').insert(rows, { upsert: true, onConflict: 'sku' });
    if (error) setMsg(error.message); else setMsg(`Importados: ${rows.length}`);
  }

  return (
    <View style={{ flex:1, padding:16, gap:12 }}>
      <Text>Importe um CSV com as colunas: category, brand, sku, name, base_unit, attributes</Text>
      <Button mode="contained" onPress={pickFile}>Selecionar CSV</Button>
      {msg && <Text>{msg}</Text>}
    </View>
  );
}
