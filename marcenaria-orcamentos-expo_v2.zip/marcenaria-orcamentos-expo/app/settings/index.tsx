import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Button, TextInput } from 'react-native-paper';
import { supabase } from '@/services/supabase';

export default function Settings() {
  const [tax, setTax] = useState('6');
  const [markup, setMarkup] = useState('30');
  const [shipping, setShipping] = useState('180');
  async function load() {
    const { data } = await supabase.from('settings').select('*').limit(1).single();
    if (data) {
      setTax(String((data.tax_pct||0)*100));
      setMarkup(String((data.markup_pct||0)*100));
      setShipping(String(data.shipping_default||0));
    }
  }
  async function save() {
    const payload = { tax_pct: Number(tax)/100, markup_pct: Number(markup)/100, shipping_default: Number(shipping) };
    await supabase.from('settings').upsert(payload, { onConflict: 'id' });
  }
  useEffect(()=>{ load(); },[]);
  return (
    <View style={{ flex:1, padding:16, gap:12 }}>
      <TextInput label="Impostos %" value={tax} onChangeText={setTax} keyboardType="numeric" />
      <TextInput label="Markup %" value={markup} onChangeText={setMarkup} keyboardType="numeric" />
      <TextInput label="Frete padrão R$" value={shipping} onChangeText={setShipping} keyboardType="numeric" />
      <Button mode="contained" onPress={save}>Salvar</Button>
    </View>
  );
}
