import { useState } from 'react';
import { View } from 'react-native';
import { Button, Text, TextInput } from 'react-native-paper';
import { signIn, signUp } from '@/services/auth';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState<string|null>(null);

  async function doLogin() {
    setMsg(null);
    try {
      await signIn(email.trim(), password);
      setMsg('Logado!');
    } catch (e:any) { setMsg(e.message); }
  }
  async function doSignup() {
    setMsg(null);
    try {
      await signUp(email.trim(), password);
      setMsg('Cadastro iniciado (verifique o email).');
    } catch (e:any) { setMsg(e.message); }
  }

  return (
    <View style={{ flex:1, justifyContent:'center', padding:16, gap:12 }}>
      <Text variant="titleLarge">Acessar</Text>
      <TextInput label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
      <TextInput label="Senha" value={password} onChangeText={setPassword} secureTextEntry />
      <Button mode="contained" onPress={doLogin}>Entrar</Button>
      <Button mode="outlined" onPress={doSignup}>Criar conta</Button>
      {msg && <Text>{msg}</Text>}
    </View>
  );
}
