import { Stack, useRouter, useSegments } from 'expo-router';
import { PaperProvider } from 'react-native-paper';
import { useEffect, useState } from 'react';
import { onAuthStateChange } from '@/services/auth';

function useProtectedRoute() {
  const [session, setSession] = useState<any>(null);
  const segments = useSegments();
  const router = useRouter();
  useEffect(() => {
    const sub = onAuthStateChange(setSession);
    return () => { sub.data.subscription.unsubscribe(); };
  }, []);
  useEffect(() => {
    const inAuthGroup = segments[0] === '(auth)';
    if (!session && !inAuthGroup) {
      router.replace('/(auth)/login');
    } else if (session && inAuthGroup) {
      router.replace('/');
    }
  }, [session, segments]);
  return session;
}

export default function Layout() {
  useProtectedRoute();
  return (
    <PaperProvider>
      <Stack screenOptions={{ headerTitle: 'Studio Planejar — Orçamentos' }} />
    </PaperProvider>
  );
}
