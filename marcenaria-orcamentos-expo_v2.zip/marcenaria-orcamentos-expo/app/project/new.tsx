import { useRouter } from 'expo-router';
import { useState } from 'react';
import { View, ScrollView } from 'react-native';
import { Button, TextInput } from 'react-native-paper';
import { supabase } from '@/services/supabase';

export default function NewProject() {
  const router = useRouter();
  const [client, setClient] = useState('');
  const [title, setTitle] = useState('');

  async function create() {
    const { data, error } = await supabase.from('projects').insert({
      client_name: client, title: title || 'Projeto'
    }).select('id').single();
    if (!error && data?.id) {
      // create default item
      await supabase.from('project_items').insert({ project_id: data.id, name: 'Item principal' });
      router.replace(`/project/${data.id}`);
    }
  }

  return (
    <ScrollView contentContainerStyle={{ padding:16 }}>
      <TextInput label="Cliente" mode="outlined" value={client} onChangeText={setClient} style={{ marginBottom: 12 }} />
      <TextInput label="Projeto" mode="outlined" value={title} onChangeText={setTitle} style={{ marginBottom: 12 }} />
      <Button mode="contained" onPress={create}>Criar</Button>
    </ScrollView>
  );
}
