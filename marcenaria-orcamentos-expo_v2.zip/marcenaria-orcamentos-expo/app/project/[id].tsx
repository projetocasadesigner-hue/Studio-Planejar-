import { useEffect, useMemo, useState } from 'react';
import { useLocalSearchParams } from 'expo-router';
import { View, ScrollView, Alert, Linking } from 'react-native';
import { ActivityIndicator, Button, Divider, IconButton, List, Text, TextInput } from 'react-native-paper';
import { supabase } from '@/services/supabase';
import { CATALOG } from '@/services/catalog';
import type { BomLine, Material } from '@/types';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

function currency(n:number){ return n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }
function uid(){ return Math.random().toString(36).slice(2,9); }

export default function EditProject() {
  const { id } = useLocalSearchParams<{id:string}>();
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState<any>(null);
  const [itemId, setItemId] = useState<string|null>(null);
  const [notes, setNotes] = useState('');

  const [bom, setBom] = useState<BomLine[]>([]);
  const [laborHours, setLaborHours] = useState(16);
  const [laborRate, setLaborRate] = useState(45);
  const [laborComplexity, setLaborComplexity] = useState(1.1);
  const [shipping, setShipping] = useState(180);
  const [taxPct, setTaxPct] = useState(0.06);
  const [markupPct, setMarkupPct] = useState(0.3);
  const [discount, setDiscount] = useState(0);

  const materialsById = useMemo(()=>Object.fromEntries(CATALOG.map(m=>[m.id,m])),[]);

  const lines = useMemo(()=> bom.map(line=>{
    const m = materialsById[line.materialId];
    const qtyFinal = line.qtyBase * (1 + (isNaN(line.wastePct) ? 0 : line.wastePct));
    const subtotal = qtyFinal * (m?.price ?? 0);
    return { ...line, material:m, qtyFinal, unitPrice: m?.price ?? 0, subtotal };
  }), [bom, materialsById]);

  const materialsTotal = useMemo(()=> lines.reduce((s,l)=>s+l.subtotal,0),[lines]);
  const laborTotal = useMemo(()=> laborHours*laborRate*laborComplexity, [laborHours,laborRate,laborComplexity]);
  const baseBeforeTax = materialsTotal + laborTotal + shipping;
  const taxes = baseBeforeTax * taxPct;
  const priceBase = baseBeforeTax + taxes;
  const finalPrice = Math.max(0, priceBase * (1 + markupPct) - discount);

  async function load() {
    setLoading(true);
    const { data: p, error } = await supabase.from('projects').select('*').eq('id', id).single();
    if (error) { setLoading(false); return; }
    setProject(p);
    const { data: items } = await supabase.from('project_items').select('*').eq('project_id', id).order('created_at', { ascending:true });
    const item = items?.[0];
    setItemId(item?.id ?? null);
    setNotes(item?.notes ?? '');
    const { data: bl } = await supabase.from('bom_lines').select('*').eq('project_item_id', item?.id);
    const restored = (bl||[]).map((r:any)=>({
      id: uid(), materialId: r.material_id, qtyBase: Number(r.qty_base), wastePct: Number(r.waste_pct||0)
    }));
    setBom(restored.length?restored:[{ id: uid(), materialId: CATALOG[0].id, qtyBase: 3.2, wastePct: 0.08 }]);
    setLoading(false);
  }

  useEffect(()=>{ load(); },[id]);

  function addLine(){ setBom(b=>[...b, { id: uid(), materialId: CATALOG[0].id, qtyBase: 1, wastePct: 0.08 }]); }
  function removeLine(id:string){ setBom(b=>b.filter(x=>x.id!==id)); }

  async function save() {
    if (!project) return;
    await supabase.from('projects').update({ client_name: project.client_name, title: project.title }).eq('id', project.id);
    if (!itemId) {
      const { data } = await supabase.from('project_items').insert({ project_id: project.id, name:'Item principal', notes }).select('id').single();
      setItemId(data.id);
    } else {
      await supabase.from('project_items').update({ notes }).eq('id', itemId);
    }
    if (itemId) {
      await supabase.from('bom_lines').delete().eq('project_item_id', itemId);
      const rows = lines.map(l => ({
        project_item_id: itemId,
        material_id: l.material?.id ?? l.materialId,
        qty_base: l.qtyBase,
        waste_pct: l.wastePct,
        unit: l.material?.unit ?? 'un',
        price: l.unitPrice,
        subtotal: l.subtotal
      }));
      if (rows.length) await supabase.from('bom_lines').insert(rows);
    }
    Alert.alert('Salvo', 'Projeto salvo com sucesso.');
  }

  async function shareWhatsApp() {
    const summary = [
      `Orçamento: ${project?.title || 'Projeto'}`,
      `Cliente: ${project?.client_name || '—'}`,
      '',
      'Materiais:',
      ...lines.map(l=>`• ${l.material?.name} — ${l.qtyFinal.toFixed(2)} ${l.material?.unit} x ${currency(l.unitPrice)} = ${currency(l.subtotal)}`),
      '',
      `Mão de obra: ${currency(laborTotal)}`,
      `Frete: ${currency(shipping)}`,
      `Impostos (${(taxPct*100).toFixed(1)}%): ${currency(taxes)}`,
      `Markup (${(markupPct*100).toFixed(0)}%): incluído`,
      discount>0?`Desconto: -${currency(discount)}`:'',
      '',
      `Total: ${currency(finalPrice)}`,
      'Validade: 7 dias',
      `Ref: ${project?.id}`
    ].filter(Boolean).join('\n');
    const url = 'https://wa.me/?text='+encodeURIComponent(summary);
    Linking.openURL(url);
  }

  async function exportPdf() {
    const html = `
      <html><body style="font-family:Arial;padding:24px">
      <h2>Orçamento — ${project?.title||'Projeto'}</h2>
      <p><b>Cliente:</b> ${project?.client_name||'—'}</p>
      <hr/>
      <h3>Materiais</h3>
      <ul>
        ${lines.map(l=>`<li>${l.material?.name} — ${l.qtyFinal.toFixed(2)} ${l.material?.unit} • ${currency(l.subtotal)}</li>`).join('')}
      </ul>
      <h3>Totais</h3>
      <p>Materiais: ${currency(materialsTotal)}<br/>
      Mão de obra: ${currency(laborTotal)}<br/>
      Frete: ${currency(shipping)}<br/>
      Impostos: ${currency(taxes)}<br/>
      <b>Total:</b> ${currency(finalPrice)}</p>
      <p><small>Validade: 7 dias • Ref: ${project?.id}</small></p>
      </body></html>`;
    const { uri } = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(uri);
  }

  if (loading) return <View style={{flex:1,alignItems:'center',justifyContent:'center'}}><ActivityIndicator/></View>;

  return (
    <ScrollView contentContainerStyle={{ padding: 12, gap: 12 }}>
      <TextInput label="Cliente" mode="outlined" value={project?.client_name||''} onChangeText={(t)=>setProject((p:any)=>({...p, client_name:t}))} />
      <TextInput label="Projeto" mode="outlined" value={project?.title||''} onChangeText={(t)=>setProject((p:any)=>({...p, title:t}))} />
      <TextInput label="Observações" mode="outlined" value={notes} onChangeText={setNotes} multiline />

      <Divider />
      <List.Subheader>Materiais (BOM)</List.Subheader>
      {lines.map(l => (
        <View key={l.id} style={{ borderWidth:1, borderColor:'#eee', borderRadius:12, padding:8, marginBottom:8 }}>
          <Text variant="labelLarge">{materialsById[l.materialId]?.name || 'Material'}</Text>
          <Text>Unidade: {materialsById[l.materialId]?.unit}</Text>
          <View style={{ flexDirection:'row', gap:8, marginTop:8 }}>
            <TextInput style={{ flex: 1 }} mode="outlined" label="Qtd. Base" keyboardType="numeric" value={String(l.qtyBase)} onChangeText={(t)=>setBom(b=>b.map(x=>x.id===l.id?{...x, qtyBase: Number(t||0)}:x))} />
            <TextInput style={{ flex: 1 }} mode="outlined" label="Perda %" keyboardType="numeric" value={String((l.wastePct*100).toFixed(2))} onChangeText={(t)=>setBom(b=>b.map(x=>x.id===l.id?{...x, wastePct: Number(t||0)/100}:x))} />
          </View>
          <View style={{ flexDirection:'row', alignItems:'center', justifyContent:'space-between' }}>
            <Button onPress={()=>{
              // cycle material for demo
              const keys = Object.keys(materialsById);
              const idx = keys.indexOf(l.materialId);
              const next = keys[(idx+1)%keys.length];
              setBom(b=>b.map(x=>x.id===l.id?{...x, materialId: next}:x));
            }}>Trocar material</Button>
            <IconButton icon="delete" onPress={()=>removeLine(l.id)} />
          </View>
          <Text>Subtotal: <Text style={{fontWeight:'bold'}}>{currency(l.subtotal)}</Text></Text>
        </View>
      ))}
      <Button icon="plus" mode="outlined" onPress={addLine}>Adicionar linha</Button>

      <Divider />
      <List.Subheader>Custos</List.Subheader>
      <View style={{ flexDirection:'row', gap:8 }}>
        <TextInput style={{ flex:1 }} label="Horas" mode="outlined" keyboardType="numeric" value={String(laborHours)} onChangeText={(t)=>setLaborHours(Number(t||0))} />
        <TextInput style={{ flex:1 }} label="Tarifa R$/h" mode="outlined" keyboardType="numeric" value={String(laborRate)} onChangeText={(t)=>setLaborRate(Number(t||0))} />
        <TextInput style={{ flex:1 }} label="Complexidade" mode="outlined" keyboardType="numeric" value={String(laborComplexity)} onChangeText={(t)=>setLaborComplexity(Number(t||0))} />
      </View>
      <View style={{ flexDirection:'row', gap:8, marginTop:8 }}>
        <TextInput style={{ flex:1 }} label="Frete R$" mode="outlined" keyboardType="numeric" value={String(shipping)} onChangeText={(t)=>setShipping(Number(t||0))} />
        <TextInput style={{ flex:1 }} label="Impostos %" mode="outlined" keyboardType="numeric" value={String((taxPct*100).toFixed(2))} onChangeText={(t)=>setTaxPct(Number(t||0)/100)} />
        <TextInput style={{ flex:1 }} label="Markup %" mode="outlined" keyboardType="numeric" value={String((markupPct*100).toFixed(0))} onChangeText={(t)=>setMarkupPct(Number(t||0)/100)} />
      </View>
      <TextInput style={{ marginTop:8 }} label="Desconto R$" mode="outlined" keyboardType="numeric" value={String(discount)} onChangeText={(t)=>setDiscount(Number(t||0))} />

      <Divider />
      <List.Subheader>Totais</List.Subheader>
      <Text>Materiais: {currency(materialsTotal)}</Text>
      <Text>Mão de obra: {currency(laborTotal)}</Text>
      <Text>Frete: {currency(shipping)}</Text>
      <Text>Impostos: {currency(taxes)}</Text>
      <Text variant="titleLarge">Total: {currency(finalPrice)}</Text>

      <View style={{ flexDirection:'row', gap:8, marginVertical:12 }}>
        <Button mode="contained" onPress={save}>Salvar</Button>
        <Button mode="outlined" onPress={shareWhatsApp}>WhatsApp</Button>
        <Button mode="outlined" onPress={exportPdf}>Exportar PDF</Button>
      </View>
    </ScrollView>
  );
}
