export type Material = {
  id: string;
  category: string;
  brand: string;
  sku: string;
  name: string;
  unit: 'm²' | 'm' | 'un' | 'par' | 'kg';
  price: number;
  attributes?: Record<string, string | number>;
  supplier: string;
};
export type BomLine = {
  id: string;
  materialId: string;
  qtyBase: number;
  wastePct: number;
};
export type Project = {
  id: string;
  client_name: string | null;
  title: string | null;
  created_at: string;
};
export type Supplier = {
  id: string;
  name: string;
  cnpj?: string | null;
  regions?: string[] | null;
};
export type MaterialPrice = {
  id: string;
  supplier_id: string;
  material_id: string;
  region?: string | null;
  price: number;
  currency?: string | null;
  valid_from?: string | null;
  valid_to?: string | null;
};
export type Settings = {
  id: string;
  user_id: string;
  tax_pct: number;
  markup_pct: number;
  shipping_default: number;
};
