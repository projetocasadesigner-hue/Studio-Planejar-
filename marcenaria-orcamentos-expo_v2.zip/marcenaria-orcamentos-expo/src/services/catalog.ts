import type { Material } from '@/types';
export const CATALOG: Material[] = [
  { id:'mdf-15-carvalho', category:'MDF', brand:'Duratex', sku:'DX-MDF-15-CARV', name:'MDF Carvalho 15mm (chapa 2750x1850)', unit:'m²', price:165, attributes:{ espessura_mm:15, chapa_m2: 2.75*1.85}, supplier:'Fornecedor Alfa' },
  { id:'mdf-18-branco', category:'MDF', brand:'Duratex', sku:'DX-MDF-18-BRAN', name:'MDF Branco Diamante 18mm (chapa 2750x1850)', unit:'m²', price:188, attributes:{ espessura_mm:18, chapa_m2: 2.75*1.85}, supplier:'Fornecedor Alfa' },
  { id:'fita-22mm', category:'Fita de Borda', brand:'Rehau', sku:'RH-FT-22', name:'Fita de borda 22mm', unit:'m', price:2.1, supplier:'Fornecedor Beta' },
  { id:'corredica-400', category:'Corrediça', brand:'Telescópica', sku:'CRD-400', name:'Corrediça telescópica 400mm', unit:'par', price:26, supplier:'Fornecedor Beta' },
  { id:'dobradiça-35', category:'Dobradiça', brand:'Hettich', sku:'HB-35', name:'Dobradiça caneco 35mm', unit:'un', price:4.5, supplier:'Fornecedor Beta' },
  { id:'puxador-ponto', category:'Puxador', brand:'Zen', sku:'ZN-PTO', name:'Puxador ponto (cobre)', unit:'un', price:12, supplier:'Fornecedor Zen' },
  { id:'kit-led', category:'Iluminação', brand:'Generic', sku:'LED-KIT', name:'Kit LED + fonte', unit:'un', price:120, supplier:'Fornecedor Ilumix' },
];

