create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  client_name text,
  client_phone text,
  title text,
  address text,
  expires_at date,
  created_at timestamp default now()
);
create table if not exists project_items (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references projects(id) on delete cascade,
  name text,
  width_mm int,
  height_mm int,
  depth_mm int,
  notes text,
  created_at timestamp default now()
);
create table if not exists bom_lines (
  id uuid primary key default gen_random_uuid(),
  project_item_id uuid references project_items(id) on delete cascade,
  material_id text,
  qty_base numeric not null,
  waste_pct numeric default 0.08,
  unit text not null,
  price numeric,
  subtotal numeric,
  created_at timestamp default now()
);

create extension if not exists pgcrypto;
create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  cnpj text,
  regions text[] default '{}',
  created_at timestamp default now()
);
create table if not exists materials (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  brand text,
  sku text unique,
  name text not null,
  base_unit text not null,
  attributes jsonb default '{}'::jsonb,
  created_at timestamp default now()
);
create table if not exists material_prices (
  id uuid primary key default gen_random_uuid(),
  supplier_id uuid references suppliers(id) on delete cascade,
  material_id uuid references materials(id) on delete cascade,
  region text,
  price numeric not null,
  currency text default 'BRL',
  valid_from date,
  valid_to date,
  created_at timestamp default now()
);
create table if not exists settings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid default auth.uid(),
  tax_pct numeric default 0.06,
  markup_pct numeric default 0.30,
  shipping_default numeric default 180
);
