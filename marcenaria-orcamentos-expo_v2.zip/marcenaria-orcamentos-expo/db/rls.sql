-- Habilitar RLS
alter table projects enable row level security;
alter table project_items enable row level security;
alter table bom_lines enable row level security;
-- Políticas básicas por usuário autenticado
create policy if not exists select_own_projects on projects for select using (auth.uid() = user_id or user_id is null);
create policy if not exists insert_projects on projects for insert with check (auth.uid() = user_id or user_id is null);
create policy if not exists update_own_projects on projects for update using (auth.uid() = user_id or user_id is null);
create policy if not exists delete_own_projects on projects for delete using (auth.uid() = user_id or user_id is null);
create policy if not exists project_items_select on project_items for select using (exists(select 1 from projects p where p.id = project_items.project_id and (auth.uid() = p.user_id or p.user_id is null)));
create policy if not exists project_items_modify on project_items for all using (exists(select 1 from projects p where p.id = project_items.project_id and (auth.uid() = p.user_id or p.user_id is null))) with check (true);
create policy if not exists bom_select on bom_lines for select using (exists(select 1 from project_items i join projects p on p.id=i.project_id where i.id = bom_lines.project_item_id and (auth.uid() = p.user_id or p.user_id is null)));
create policy if not exists bom_modify on bom_lines for all using (exists(select 1 from project_items i join projects p on p.id=i.project_id where i.id = bom_lines.project_item_id and (auth.uid() = p.user_id or p.user_id is null))) with check (true);

alter table settings enable row level security;
create policy if not exists settings_ro on settings for select using (auth.uid() = user_id);
create policy if not exists settings_rw on settings for all using (auth.uid() = user_id) with check (auth.uid() = coalesce(user_id, auth.uid()));
