# Orçamentos de Marcenaria — App (Expo + Supabase)

## Requisitos
- Node 18+
- Conta Expo + EAS CLI
- Supabase (URL e Anon Key)

## Setup
```bash
npm i
cp .env.example .env
# edite .env com SUPABASE_URL e SUPABASE_ANON_KEY
```
O app lê as variáveis via `app.config.js` (expo-constants).

### Banco (Supabase)
Execute em SQL Editor:
- `db/schema.sql`
- `db/rls.sql`

## Run
```bash
npm start
```
Abra no Expo Go (Android/iOS).

## Build Android/iOS (EAS)
- Instale: `npm i -g eas-cli`
- Login: `eas login`
- Configure projeto: `eas init` (substitua o `projectId` em `app.config.js` ou `app.json`)
- Android AAB: `eas build --platform android`
- iOS IPA: `eas build --platform ios`

## Funcionalidades
- Listar, criar, editar **Projetos**
- **BOM** com linhas, perda %, preço unitário do catálogo mock
- Cálculo de **materiais, mão de obra, frete, impostos, markup e desconto**
- **WhatsApp** (wa.me)
- **Exportar PDF** (expo-print + expo-sharing)

## Observações
- O catálogo ainda é mock (local). Para catálogos de fornecedores, crie tabelas `materials`, `material_prices` e uma tela de importação CSV.
- Ative Auth do Supabase para travar por usuário e associe `projects.user_id` ao `auth.uid()` no insert.


## Novidades deste pacote
- **Login/Sessão** (Supabase Auth) com proteção de rotas
- **Materiais** (lista + importação CSV)
- **Configurações** (impostos, markup, frete padrão) persistidas por usuário
- SQL expandido: `suppliers`, `materials`, `material_prices`, `settings`

### CSV de Materiais — Modelo
```csv
category,brand,sku,name,base_unit,attributes
MDF,Duratex,DX-MDF-15-CARV,MDF Carvalho 15mm (chapa 2750x1850),m²,"{"espessura_mm":15,"chapa_m2":5.0875}"
Fita de Borda,Rehau,RH-FT-22,Fita de borda 22mm,m,"{}"
```

### Dicas de Publicação (serviços)
- **Grátis / testes**: Expo Go (QR Code), GitHub Releases (APK), Netlify/Vercel (web/PWA)
- **Builds OTA e binários**: Expo EAS (pago/por uso), Microsoft App Center (gratuito limitado)
- **Lojas**: Google Play Console (pago único), Apple App Store (pago anual)
